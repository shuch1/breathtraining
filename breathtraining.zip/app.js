const els = {
  mainTimer: document.querySelector("#mainTimer"),
  phaseLabel: document.querySelector("#phaseLabel"),
  summary: document.querySelector("#summary"),
  inhaleSeconds: document.querySelector("#inhaleSeconds"),
  holdInSeconds: document.querySelector("#holdInSeconds"),
  exhaleSeconds: document.querySelector("#exhaleSeconds"),
  holdOutSeconds: document.querySelector("#holdOutSeconds"),
  durationMinutes: document.querySelector("#durationMinutes"),
  cycleCount: document.querySelector("#cycleCount"),
  useCycles: document.querySelector("#useCycles"),
  leadSeconds: document.querySelector("#leadSeconds"),
  preBeepSeconds: document.querySelector("#preBeepSeconds"),
  presetSlots: document.querySelector("#presetSlots"),
  startPauseButton: document.querySelector("#startPauseButton"),
  stopButton: document.querySelector("#stopButton"),
};

const PRESET_KEY = "breathtraining:presets:v1";
const PRESET_COUNT = 6;
const phaseNames = ["Inhale", "Hold after inhale", "Exhale", "Hold after exhale"];

const state = {
  audioContext: null,
  status: "idle",
  startedAt: 0,
  pausedAt: 0,
  pausedTotal: 0,
  plan: null,
  events: [],
  nextEventIndex: 0,
  tickId: null,
};

function numberValue(input, fallback) {
  const value = Number(input.value);
  return Number.isFinite(value) ? value : fallback;
}

function clamp(value, min) {
  return Math.max(min, value);
}

function readSettings() {
  const phaseDurations = [
    clamp(numberValue(els.inhaleSeconds, 5), 0),
    clamp(numberValue(els.holdInSeconds, 45), 0),
    clamp(numberValue(els.exhaleSeconds, 5), 0),
    clamp(numberValue(els.holdOutSeconds, 5), 0),
  ];
  const cycleSeconds = phaseDurations.reduce((sum, value) => sum + value, 0);
  const leadSeconds = clamp(numberValue(els.leadSeconds, 15), 0);
  const preBeepSeconds = clamp(numberValue(els.preBeepSeconds, 3), 0);
  const useCycles = els.useCycles.checked;
  const requestedCycles = Math.ceil(clamp(numberValue(els.cycleCount, 15), 1));
  const requestedSeconds = clamp(numberValue(els.durationMinutes, 15), 1) * 60;
  const timeModeCycles = cycleSeconds > 0 ? Math.ceil(requestedSeconds / cycleSeconds) : 0;
  const cycles = useCycles ? requestedCycles : timeModeCycles;
  const exerciseSeconds = cycles * cycleSeconds;

  if (!useCycles && cycleSeconds > 0) {
    els.cycleCount.value = String(timeModeCycles);
  }

  return {
    phaseDurations,
    cycleSeconds,
    cycles,
    exerciseSeconds,
    leadSeconds,
    preBeepSeconds,
    useCycles,
    isValid: cycleSeconds > 0,
  };
}

function formatClock(seconds, rounding = "ceil") {
  const round = rounding === "floor" ? Math.floor : Math.ceil;
  const rounded = Math.max(0, round(seconds));
  const minutes = Math.floor(rounded / 60);
  const secs = rounded % 60;
  return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function currentFormValues() {
  return {
    inhaleSeconds: numberValue(els.inhaleSeconds, 0),
    holdInSeconds: numberValue(els.holdInSeconds, 0),
    exhaleSeconds: numberValue(els.exhaleSeconds, 0),
    holdOutSeconds: numberValue(els.holdOutSeconds, 0),
    durationMinutes: numberValue(els.durationMinutes, 15),
    cycleCount: numberValue(els.cycleCount, 15),
    useCycles: els.useCycles.checked,
    leadSeconds: numberValue(els.leadSeconds, 15),
    preBeepSeconds: numberValue(els.preBeepSeconds, 3),
  };
}

function applyFormValues(values) {
  els.inhaleSeconds.value = values.inhaleSeconds ?? 5;
  els.holdInSeconds.value = values.holdInSeconds ?? 45;
  els.exhaleSeconds.value = values.exhaleSeconds ?? 5;
  els.holdOutSeconds.value = values.holdOutSeconds ?? 5;
  els.durationMinutes.value = values.durationMinutes ?? 15;
  els.cycleCount.value = values.cycleCount ?? 15;
  els.useCycles.checked = Boolean(values.useCycles);
  els.leadSeconds.value = values.leadSeconds ?? 15;
  els.preBeepSeconds.value = values.preBeepSeconds ?? 3;
  updateModeControls();
  updateDisplay();
}

function readPresets() {
  try {
    const parsed = JSON.parse(localStorage.getItem(PRESET_KEY));
    if (Array.isArray(parsed)) {
      return Array.from({ length: PRESET_COUNT }, (_, index) => parsed[index] || null);
    }
  } catch {
    // Ignore broken local data and start with empty slots.
  }

  return Array.from({ length: PRESET_COUNT }, () => null);
}

function writePresets(presets) {
  localStorage.setItem(PRESET_KEY, JSON.stringify(presets));
}

function savePreset(index) {
  const presets = readPresets();
  presets[index] = currentFormValues();
  writePresets(presets);
  renderPresets();
}

function loadPreset(index) {
  const preset = readPresets()[index];
  if (!preset) return;
  applyFormValues(preset);
}

function renderPresets() {
  const presets = readPresets();
  els.presetSlots.innerHTML = "";

  presets.forEach((preset, index) => {
    const slot = document.createElement("div");
    slot.className = `preset-slot${preset ? "" : " empty"}`;

    const loadButton = document.createElement("button");
    loadButton.type = "button";
    loadButton.className = "load-preset";
    loadButton.textContent = `Load ${index + 1}`;
    loadButton.disabled = !preset;
    loadButton.addEventListener("click", () => loadPreset(index));

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.className = "save-preset";
    saveButton.textContent = `Save ${index + 1}`;
    saveButton.addEventListener("click", () => savePreset(index));

    slot.append(loadButton, saveButton);
    els.presetSlots.append(slot);
  });
}

function ensureAudio() {
  if (!state.audioContext) {
    state.audioContext = new AudioContext();
  }
  return state.audioContext;
}

async function beep(kind) {
  const context = ensureAudio();
  if (context.state === "suspended") {
    await context.resume();
  }

  const now = context.currentTime;
  const pulses =
    kind === "cycle"
      ? [
          { offset: 0, duration: 0.07, frequency: 900, volume: 0.22 },
          { offset: 0.13, duration: 0.07, frequency: 900, volume: 0.22 },
        ]
      : [
          {
            offset: 0,
            duration: kind === "long" ? 0.65 : 0.13,
            frequency: kind === "long" ? 520 : 760,
            volume: kind === "long" ? 0.34 : 0.24,
          },
        ];

  pulses.forEach((pulse) => {
    const osc = context.createOscillator();
    const gain = context.createGain();
    const start = now + pulse.offset;
    const fade = Math.min(0.015, pulse.duration / 3);

    osc.type = "sine";
    osc.frequency.setValueAtTime(pulse.frequency, start);
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(pulse.volume, start + fade);
    gain.gain.setValueAtTime(pulse.volume, start + pulse.duration - fade);
    gain.gain.linearRampToValueAtTime(0, start + pulse.duration);
    osc.connect(gain).connect(context.destination);
    osc.start(start);
    osc.stop(start + pulse.duration + 0.01);
  });
}

function buildEvents(plan) {
  const events = [];
  const preBeepAt = plan.leadSeconds - plan.preBeepSeconds;

  if (plan.preBeepSeconds > 0 && preBeepAt >= 0) {
    events.push({ at: preBeepAt, kind: "short", label: "Get ready" });
  }

  events.push({ at: plan.leadSeconds, kind: "long", label: "Start" });

  let cursor = plan.leadSeconds;
  for (let cycle = 0; cycle < plan.cycles; cycle += 1) {
    let lastPhaseIndex = 0;
    for (let index = 0; index < plan.phaseDurations.length; index += 1) {
      if (plan.phaseDurations[index] > 0) {
        lastPhaseIndex = index;
      }
    }

    for (let phase = 0; phase < plan.phaseDurations.length; phase += 1) {
      const duration = plan.phaseDurations[phase];
      if (duration <= 0) continue;

      cursor += duration;
      const isFinalEvent = cursor >= plan.leadSeconds + plan.exerciseSeconds;
      const isCycleBoundary = phase === lastPhaseIndex;
      events.push({
        at: cursor,
        kind: isFinalEvent ? "long" : isCycleBoundary ? "cycle" : "short",
        label: isCycleBoundary ? "Cycle complete" : phaseNames[phase + 1],
      });
    }
  }

  return events.sort((a, b) => a.at - b.at);
}

function currentElapsed() {
  if (state.status === "paused") {
    return (state.pausedAt - state.startedAt - state.pausedTotal) / 1000;
  }
  return (performance.now() - state.startedAt - state.pausedTotal) / 1000;
}

function currentExerciseElapsed() {
  return Math.max(0, currentElapsed() - state.plan.leadSeconds);
}

function currentPhase(elapsedExercise) {
  const cyclePosition = elapsedExercise % state.plan.cycleSeconds;
  let cursor = 0;

  for (let index = 0; index < state.plan.phaseDurations.length; index += 1) {
    const duration = state.plan.phaseDurations[index];
    if (duration <= 0) continue;

    if (cyclePosition < cursor + duration || index === state.plan.phaseDurations.length - 1) {
      return {
        name: phaseNames[index],
        remaining: cursor + duration - cyclePosition,
      };
    }
    cursor += duration;
  }

  return { name: "Inhale", remaining: state.plan.phaseDurations[0] };
}

function updateSummary(plan = readSettings()) {
  if (!plan.isValid) {
    els.summary.textContent = "Set breathing times";
    return;
  }

  const mode = plan.useCycles ? "stopwatch" : "timer";
  els.summary.textContent = `${plan.cycles} cycles - ${formatClock(plan.exerciseSeconds)} - ${mode}`;
}

function updateDisplay() {
  if (!state.plan) {
    const plan = readSettings();
    els.mainTimer.textContent = plan.useCycles || !plan.isValid ? "00:00" : formatClock(plan.exerciseSeconds);
    els.phaseLabel.textContent = "Ready";
    updateSummary(plan);
    updateStartAvailability(plan);
    return;
  }

  const elapsed = currentElapsed();

  if (elapsed < state.plan.leadSeconds) {
    els.mainTimer.textContent = formatClock(state.plan.leadSeconds - elapsed);
    els.phaseLabel.textContent = "Starting soon";
    updateStartAvailability(state.plan);
    return;
  }

  const exerciseElapsed = Math.min(currentExerciseElapsed(), state.plan.exerciseSeconds);

  if (state.plan.useCycles) {
    els.mainTimer.textContent = formatClock(exerciseElapsed, "floor");
  } else {
    els.mainTimer.textContent = formatClock(state.plan.exerciseSeconds - exerciseElapsed);
  }

  if (exerciseElapsed >= state.plan.exerciseSeconds) {
    els.phaseLabel.textContent = "Done";
    updateStartAvailability(state.plan);
    return;
  }

  const phase = currentPhase(exerciseElapsed);
  const cycle = Math.floor(exerciseElapsed / state.plan.cycleSeconds) + 1;
  els.phaseLabel.textContent = `${phase.name} - ${formatClock(phase.remaining)} - ${cycle}/${state.plan.cycles}`;
  updateStartAvailability(state.plan);
}

function tick() {
  if (state.status !== "running") return;

  const elapsed = currentElapsed();
  while (state.nextEventIndex < state.events.length && elapsed >= state.events[state.nextEventIndex].at) {
    beep(state.events[state.nextEventIndex].kind);
    state.nextEventIndex += 1;
  }

  updateDisplay();

  if (elapsed >= state.plan.leadSeconds + state.plan.exerciseSeconds) {
    finish();
  }
}

function setRunningUi(isRunning) {
  document.body.classList.toggle("session-active", isRunning);
  els.startPauseButton.textContent = isRunning ? "Pause" : "Start";
  els.startPauseButton.classList.toggle("running", isRunning);
  els.stopButton.disabled = !isRunning && state.status !== "paused";
  els.stopButton.classList.toggle("stop-active", isRunning || state.status === "paused");
}

function updateStartAvailability(plan = readSettings()) {
  const canStart = plan.isValid || state.status === "running" || state.status === "paused";
  els.startPauseButton.disabled = !canStart;
}

async function start() {
  const context = ensureAudio();
  await context.resume();

  state.plan = readSettings();
  if (!state.plan.isValid) {
    state.plan = null;
    updateDisplay();
    return;
  }

  state.events = buildEvents(state.plan);
  state.nextEventIndex = 0;
  state.startedAt = performance.now();
  state.pausedAt = 0;
  state.pausedTotal = 0;
  state.status = "running";

  updateSummary(state.plan);
  setRunningUi(true);
  clearInterval(state.tickId);
  state.tickId = setInterval(tick, 100);
  tick();
}

function pause() {
  state.pausedAt = performance.now();
  state.status = "paused";
  clearInterval(state.tickId);
  setRunningUi(false);
  updateDisplay();
}

function resume() {
  state.pausedTotal += performance.now() - state.pausedAt;
  state.pausedAt = 0;
  state.status = "running";
  clearInterval(state.tickId);
  state.tickId = setInterval(tick, 100);
  setRunningUi(true);
  tick();
}

function stop() {
  state.status = "idle";
  state.plan = null;
  state.events = [];
  state.nextEventIndex = 0;
  clearInterval(state.tickId);
  setRunningUi(false);
  updateDisplay();
}

function finish() {
  state.status = "done";
  clearInterval(state.tickId);
  updateDisplay();
  setRunningUi(false);
  els.stopButton.disabled = true;
}

function updateModeControls() {
  els.durationMinutes.disabled = els.useCycles.checked;
  els.cycleCount.disabled = !els.useCycles.checked;
}

els.useCycles.addEventListener("change", () => {
  updateModeControls();
  if (state.status === "idle" || state.status === "done") updateDisplay();
});

document.querySelectorAll("input").forEach((input) => {
  input.addEventListener("input", () => {
    if (state.status === "idle" || state.status === "done") updateDisplay();
  });
});

els.startPauseButton.addEventListener("click", () => {
  if (state.status === "running") {
    pause();
  } else if (state.status === "paused") {
    resume();
  } else {
    start();
  }
});

els.stopButton.addEventListener("click", stop);

renderPresets();
updateModeControls();
updateDisplay();
